
PROMPT *******************************************************************************************
PROMPT *   SCRIPT NAME: assessment_task.sql                                                      *
PROMPT *   DESCRIPTION: This script is an assessment task for recruitment purposes               *  
PROMPT *   AUTHOR:      Adam Jewiarz, ajewiarz@unictec.pl                                        *
PROMPT *******************************************************************************************

SET LINESIZE 300
SET PAGESIZE 2000
SET ECHO OFF
SET VERIFY OFF
SET ESCAPE OFF 

ACCEPT logfile_name CHAR PROMPT 'Enter log file name:'
SPOOL &logfile_name

PROMPT
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
PROMPT           Log file: &logfile_name 
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

PROMPT
SELECT TO_CHAR(SYSTIMESTAMP,'YYYY-MM-DD HH24:mi:ss.ff') AS "* Started at:" from dual;
 
PROMPT
PROMPT * Creating sequence for autonum DOCUMENTS.DOCUMENT_ID column:

CREATE SEQUENCE document_id_sq
CACHE 2;

PROMPT
PROMPT  * Creating table:

CREATE TABLE documents 
(
document_id  INTEGER DEFAULT document_id_sq.nextval CONSTRAINT  document_id_pk PRIMARY KEY,
document_name VARCHAR2(50) CONSTRAINT document_name_nn NOT NULL,
document_desc VARCHAR2(4000),
record_timestamp TIMESTAMP WITH LOCAL TIME ZONE  DEFAULT TO_TIMESTAMP('1900-01-01','YYYY-MM-DD') CONSTRAINT record_timestamp_nn NOT NULL,
timestamp TIMESTAMP WITH LOCAL TIME ZONE DEFAULT TO_TIMESTAMP('1900-01-01','YYYY-MM-DD') CONSTRAINT timestamp_nn NOT NULL,
record_user_id VARCHAR2(50) DEFAULT 'DUMMY_INSERT_USER' CONSTRAINT record_user_id_nn NOT NULL,
user_id VARCHAR2(50) DEFAULT 'DUMMY_UPDATE_USER' CONSTRAINT user_id_nn NOT NULL
);

PROMPT
PROMPT * Creating trigger on table DOCUMENTS:

CREATE OR REPLACE TRIGGER insert_update_log
BEFORE INSERT OR UPDATE
ON documents
FOR EACH ROW 
DECLARE  
	v_timestamp documents.record_timestamp%TYPE;
	v_user documents.record_user_id%TYPE;
BEGIN
	IF INSERTING THEN 
       	v_timestamp:= CURRENT_TIMESTAMP;
        v_user:= USER;
		:new.record_timestamp := v_timestamp;
        :new.record_user_id := v_user;
        :new.timestamp := v_timestamp;
        :new.user_id := v_user;
	ELSIF UPDATING THEN 
        :new.timestamp := CURRENT_TIMESTAMP;
        :new.user_id := USER;
	END IF;
END;
/

PROMPT
PROMPT  * Creating package:

CREATE OR REPLACE PACKAGE manifold AS
	FUNCTION validate_pesel(pesel_in VARCHAR2) RETURN BOOLEAN; -- validation of PESEL number 
	PROCEDURE print_documents; -- printing documents name from table DOCUMENTS
END manifold;
/

PROMPT
PROMPT * Creating package body:

CREATE OR REPLACE PACKAGE BODY manifold AS
	-- function: validation of PESEL number  
	FUNCTION validate_pesel(pesel_in VARCHAR2) RETURN BOOLEAN
	IS
		TYPE vector_of_11_t     IS VARRAY(11) of INTEGER;
		v_weights 			    vector_of_11_t:=vector_of_11_t();
		v_control_sum 		    INTEGER;
        v_is_valid 			    BOOLEAN;
		v_index 			    INTEGER;
        v_message				VARCHAR2(50);   
        x_pesel_is_null 		EXCEPTION; -- when PESEL number is null
        x_pesel_wrong_lenght 	EXCEPTION; -- when too many or not enough characters in PESEL number
        x_pesel_wrong_ctl_sum	EXCEPTION; -- when control sum of PESEL number is not valid
        x_pesel_alfa_in			EXCEPTION; -- when not every character of PESEL number is a digit
        x_pesel_zeroes 			EXCEPTION; -- when PESEL number is '00000000000'
       
	BEGIN
		v_weights.EXTEND(11);
		v_weights(1):=1;
		v_weights(2):=3;
		v_weights(3):=7;
		v_weights(4):=9;
		v_weights(5):=1;
		v_weights(6):=3;
		v_weights(7):=7;
		v_weights(8):=9;
		v_weights(9):=1;
		v_weights(10):=3;
		v_weights(11):=1;
		v_control_sum:=0;

		IF  pesel_in IS NULL THEN 
				v_is_valid:=FALSE;
				v_message:='PESEL number is null.';
				RAISE x_pesel_is_null; 
			ELSIF (LENGTH(pesel_in)<>11) THEN 
				v_is_valid:=FALSE;
				v_message:='Too many or not enough characters in PESEL number.';
				RAISE x_pesel_wrong_lenght;
			ELSIF (NOT(REGEXP_LIKE(pesel_in,'^[[:digit:]]{11}'))) THEN 
				v_is_valid:=FALSE;
				v_message:='Not every character of PESEL number is a digit.';
				RAISE x_pesel_alfa_in;
			ELSIF pesel_in='00000000000' THEN 
				v_is_valid:=FALSE;
				v_message:='PESEL number: ''00000000000'' doesn''t exist.';
				RAISE x_pesel_zeroes;
			ELSE 
				FOR v_index IN 1 .. 11 LOOP
					v_control_sum:=v_control_sum+(TO_NUMBER(SUBSTR(pesel_in,v_index,1)))*v_weights(v_index);
				END LOOP;
				IF (MOD(v_control_sum, 10))=0 THEN v_is_valid := TRUE; -- Control digit of PESEL number is valid 
					ELSE 
						v_is_valid:=FALSE;
						v_message:='Control sum of PESEL number is not valid';
						RAISE x_pesel_wrong_ctl_sum;
				END IF;
		END IF;
        RETURN v_is_valid;        
	EXCEPTION 
		WHEN x_pesel_is_null OR 
             x_pesel_wrong_lenght OR 
             x_pesel_wrong_ctl_sum OR 
             x_pesel_alfa_in OR 
             x_pesel_zeroes THEN 
             DBMS_OUTPUT.PUT_LINE('Wrong input data: '||v_message);
             RETURN v_is_valid;
        WHEN OTHERS THEN 
			DBMS_OUTPUT.PUT_LINE('Error Code: '||SQLCODE);
			DBMS_OUTPUT.PUT_LINE('Error Message: '||SQLERRM);
            -- RAISE; -- uncomment this line when OTHERS exception should be popagated up to parent subprogram level
	END validate_pesel; 
	
	-- procedure: printing documents name from table DOCUMENTS
    PROCEDURE print_documents 
    IS
        v_document_name documents.document_name%TYPE;
        v_document_desc documents.document_desc%TYPE;
        CURSOR documents_c IS 
            SELECT document_name, document_desc 
            FROM documents
            ORDER BY document_name;

    BEGIN
        OPEN documents_c;
        LOOP  
            FETCH documents_c INTO v_document_name, v_document_desc;
            EXIT WHEN documents_c%NOTFOUND;
            IF v_document_desc IS NULL THEN v_document_name:='No Description';
            END IF;
            DBMS_OUTPUT.PUT_LINE(v_document_name); 
        END LOOP;
    EXCEPTION
        WHEN OTHERS THEN 
			DBMS_OUTPUT.PUT_LINE('Error Code: '||SQLCODE);
			DBMS_OUTPUT.PUT_LINE('Error Message: '||SQLERRM);
            -- RAISE; -- uncomment this line when OTHERS exception should be popageted up to parent subprogram level
        CLOSE documents_c;
    END print_documents;
END;
/

PROMPT 
PROMPT  * Inserting a few example rows into DOCUMENTS table:

SET DEF OFF
SET ECHO ON 

INSERT INTO documents (document_name, document_desc) VALUES ('FV 23003/12/2019','Invoice, object of transaction: mutidimensional molecular dezintegrator, client: Omnispace Co.');
INSERT INTO documents (document_name, document_desc) VALUES ('Clarification for Tax Office','Explanation concerns interpretation of VAT regulations');
INSERT INTO documents (document_name, document_desc) VALUES ('D&I/32VIP/2018/IT','Contract: ''Delivery, installation and configuration server software at Omnispace Co.''');
INSERT INTO documents (document_name, document_desc) VALUES ('Note 05/12/2019',NULL);
INSERT INTO documents (document_name, document_desc) VALUES ('Note 11/11/2019',NULL);
INSERT INTO documents (document_name, document_desc) VALUES ('Call to be a witness',NULL);
INSERT INTO documents (document_name, document_desc) VALUES ('FV 23004/12/2019','Invoice, object of transaction: Laser blaster MG225XE, client: Omnispace Co.');
COMMIT;

SET ECHO OFF
SET DEF ON

PROMPT
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
PROMPT           Log file: &logfile_name 
PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
PROMPT

SELECT TO_CHAR(SYSTIMESTAMP,'YYYY-MM-DD HH24:mi:ss.ff') AS "* Completed at:" from dual;

PROMPT EOF
SPOOL OFF
